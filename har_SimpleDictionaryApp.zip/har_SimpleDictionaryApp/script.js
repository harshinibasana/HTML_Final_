// ===============================
// Simple Dictionary App
// ===============================

// Event listeners for click and Enter key
// (Triggers searchWord() when user clicks Search or presses Enter)
document.getElementById("searchBtn").addEventListener("click", () => searchWord());
document.getElementById("wordInput").addEventListener("keypress", (e) => {
  if (e.key === "Enter") searchWord();
});

// ===============================
// Function: Fetch data from Dictionary API
// ===============================
const searchWord = () => {
  const word = document.getElementById("wordInput").value.trim();
  const resultDiv = document.getElementById("result");

  if (!word) {
    resultDiv.innerHTML = `<p>Please enter a word.</p>`;
    return;
  }

  // API URL
  const url = `https://api.dictionaryapi.dev/api/v2/entries/en/${word}`;

  // ✅ Fetch API for HTTP call
  fetch(url)
    .then(response => {
      if (!response.ok) throw new Error("Word not found");
      return response.json();
    })
    .then(data => {
      const entry = data[0];
      const definition = entry.meanings[0].definitions[0].definition;
      const synonyms = entry.meanings[0].synonyms;

      // ✅ Using filter() + map() + join()
      // filter(): remove empty or duplicate synonyms
      // map(): format each synonym
      // join(): combine them into a comma-separated string
      const synonymList = synonyms && synonyms.length > 0
        ? synonyms
            .filter((s, index, arr) => s && arr.indexOf(s) === index) // removes blanks & duplicates
            .map(s => s)
            .join(", ")
        : "No synonyms available.";

      // ✅ Template literals used for dynamic HTML structure
      resultDiv.innerHTML = `
        <div class="result-card">
          <div class="word">${entry.word}</div>
          <div class="meaning"><strong>Meaning:</strong> ${definition}</div>
          <div class="synonyms"><strong>Synonyms:</strong> ${synonymList}</div>
        </div>
      `;
    })
    .catch(error => {
      // ✅ Error handling: show message if word not found
      resultDiv.innerHTML = `<p style="color:red;">Word not found! Please try another.</p>`;
    });
};


// • Fetch API → Used for HTTP requests to get dictionary data (line 25)
// • Arrow functions → Used for concise syntax in event listeners and searchWord
// • Template literals → Used in resultDiv.innerHTML (line 49)
// • Array methods → filter(), map(), and join() used to process synonyms (line 37)
// • Event listeners → Used for button click and Enter key (lines 7–10)
// • DOM manipulation → Uses innerHTML to show results dynamically (line 49)
